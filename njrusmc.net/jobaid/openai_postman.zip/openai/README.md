# OpenAI/ChatGPT Postman Collection
Postman collection to interact with the OpenAI HTTP API:
  * Retrieving models
  * Chat interaction examples using gpt-3.5-turbo, gpt-4, and gpt-4-turbo-preview
  * Text and image editing
  * Language transcription and translation
  * Moderation testing
  * LLM fine tuning
  * Vector embeddings

## Usage
Be sure to check the folder descriptions for a summary of each workflow,
and note that each request has at least one "example" showing the response
format.

## Environments
There is one environment included with the collection,
  * `openai`: Provides an easy mechanism to include your personal
    API key (bearer token) when using the example requests.

You can add custom environments for your own networks as you see fit.

## Copyright
Copyright 2024 Nicholas Russo.

Consumers may download and edit any document in this collection for personal
use only. Downloading and editing any document in this collection for
redistribution is prohibited.

All rights reserved.
