# Disqus HTTP API
Postman collection to manage the aforementioned product.

## Usage
Be sure to check the folder descriptions for a summary of each workflow,
and note that each request has at least one "example" showing the response
format.

## Environments
There is one environment included with the collection,
  * `template`: Users should populate this template with their specific values.
    You will need to create and register a new application via the Disqus
    website. Once that process is complete, the UI will present the
    required credentials. Note that the `api_secret` is not required for
    read-only operations.

You can add custom environments for your own projects as you see fit.

## Copyright
Copyright 2024 Nicholas Russo.

Consumers may download and edit any document in this collection for personal
use only. Downloading and editing any document in this collection for
redistribution is prohibited.

All rights reserved.
