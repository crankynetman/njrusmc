# Graphical Network Simulator 3 (GNS3) REST API
Postman collection to manage the aforementioned product.

## Usage
Be sure to check the folder descriptions for a summary of each workflow,
and note that each request has at least one "example" showing the response
format.

The general workflow for building GNS3 topologies is as follows:
  - Get the computes (GNS3 server nodes)
  - Create a project
  - Create/retrieve node templates
  - Provision nodes into the project from the template
  - Interconnect nodes with links
  - IOU only: upload startup config
  - Start nodes
  - Non-IOU: perform initial configuration
  - Run topology checks/tests (connect to dynamic console ports)
  - Stop nodes
  - Optionally create/manage snapshots
  - Delete project

## Environments
There is one environment included with the collection,
  * `baseline`: Contains host/credential information which targets the
    local server node given default installation parameters. If you want
    to target the GNS3 VM rather than the local server, use that specific
    host and HTTP port 80 (not 3080) by default.

You can add custom environments for your own networks as you see fit.

## Copyright
Copyright 2024 Nicholas Russo.

Consumers may download and edit any document in this collection for personal
use only. Downloading and editing any document in this collection for
redistribution is prohibited.

All rights reserved.
