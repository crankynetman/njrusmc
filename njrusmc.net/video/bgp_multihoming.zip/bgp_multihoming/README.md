# BGP Multi-homing Reference Files
Configurations and diagrams relating to the videos. Currently contains:
  1. Network Overview
  2. iBGP full mesh + ECMP
  3. iBGP full mesh + UCMP (DMZ Link Bandwidth)
  4. iBGP full mesh + Primary/Backup (best external)
  5. iBGP Route Reflector (RR) Overview
  6. iBGP RR + Shadow Session + ECMP
  7. iBGP RR + Shadow RR + ECMP
  8. iBGP RR + Primary/Backup (Add-path)
  9. iBGP RR + MPLS Transport (BGP-free Core)
  10. iBGP RR + MPLS + ECMP (Add-path)
  11. iBGP RR + MPLS + Shadow RR + Primary/Backup (best external)
  12. iBGP RR + MPLS VPN Unique RD + UCMP (DMZ Link Bandwidth)

## Usage and Warranty
These files are used for learning and lab purposes only. RFC1918, RFC3849,
and RFC5737 prefixes have been used exclusively to avoid any overlap
with public networks. Any unlikely overlap that may exist is coincidental.

## Copyright
Copyright 2021 Nicholas Russo.

Consumers may download and edit any document in this collection for personal
use only. Downloading and editing any document in this collection for
redistribution is prohibited.

All rights reserved.
